SPACECRAFT ATTITUDE and DYNAMICS PROJECT INSTRUCTIONS

Run the script data_38 to initialize the constant parameters;
Run the simulink model simulink_38 with the simulation time set to T_orbit to simulate an entire orbit;
Run the script figures_38 to obtain the figures we inserted in the report